/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as annunci from "../annunci.js";
import type * as assistente from "../assistente.js";
import type * as chat from "../chat.js";
import type * as comunita from "../comunita.js";
import type * as foto from "../foto.js";
import type * as http from "../http.js";
import type * as labirinto from "../labirinto.js";
import type * as passi from "../passi.js";
import type * as politica from "../politica.js";
import type * as programmerSpace from "../programmerSpace.js";
import type * as pushIdentities from "../pushIdentities.js";
import type * as pushNotifications from "../pushNotifications.js";
import type * as quiz from "../quiz.js";
import type * as ricetteUtenti from "../ricetteUtenti.js";
import type * as segnalazioni from "../segnalazioni.js";
import type * as serraniMondo from "../serraniMondo.js";
import type * as siteOverrides from "../siteOverrides.js";
import type * as turista from "../turista.js";
import type * as users from "../users.js";
import type * as webcamLinks from "../webcamLinks.js";
import type * as youalert from "../youalert.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  annunci: typeof annunci;
  assistente: typeof assistente;
  chat: typeof chat;
  comunita: typeof comunita;
  foto: typeof foto;
  http: typeof http;
  labirinto: typeof labirinto;
  passi: typeof passi;
  politica: typeof politica;
  programmerSpace: typeof programmerSpace;
  pushIdentities: typeof pushIdentities;
  pushNotifications: typeof pushNotifications;
  quiz: typeof quiz;
  ricetteUtenti: typeof ricetteUtenti;
  segnalazioni: typeof segnalazioni;
  serraniMondo: typeof serraniMondo;
  siteOverrides: typeof siteOverrides;
  turista: typeof turista;
  users: typeof users;
  webcamLinks: typeof webcamLinks;
  youalert: typeof youalert;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
